<!DOCTYPE html>
<html>
<body>

<?php
$t = date("H");

if ($t < "20") {
    echo "Have a good day!";
}
?>

</body>
</html>
